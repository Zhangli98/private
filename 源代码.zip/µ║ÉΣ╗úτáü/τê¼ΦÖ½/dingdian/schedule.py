# -*- coding: utf-8 -*-
import logging
logging.basicConfig(level = logging.INFO,format = '%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)
def schedule(totalVuls,currentVuls):
    percent = currentVuls/totalVuls
    if(percent>1):
        percent =1
    logger.info( 'Totaly : %d , got %d ' % (totalVuls, int(currentVuls)))

    str =  ' %.2f%% ' % (percent * 100)+'[' + '>' * int((100 * percent)) + ' ' * int((1 - percent) * 100) + ']'
    logger.info( str)

def schedule2(totalVuls,currentVuls):
    percent = currentVuls/totalVuls
    logger.info( 'Totaly : %d , got %d ' % (totalVuls, int(currentVuls)))

    str =  ' %.2f%% ' % (percent * 100)+'[' + '>' * int((100 * percent)) + ' ' * int((1 - percent) * 100) + ']'
    logger.info(str)