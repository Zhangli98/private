# -*- coding: utf-8 -*-

# Define here the models for your scraped items
#
# See documentation in:
# https://doc.scrapy.org/en/latest/topics/items.html

import scrapy


class DingdianItem(scrapy.Item):
    # define the fields for your item here like:
    name = scrapy.Field()

    author = scrapy.Field()

    novelUrl = scrapy.Field()

    category = scrapy.Field()

    updateTime = scrapy.Field()

class NsfocusItem(scrapy.Item):
    #text = scrapy.Field()
    url = scrapy.Field()
    title = scrapy.Field()
    cveID = scrapy.Field()
    publishTime = scrapy.Field()
    updateTime = scrapy.Field()
    effectSys = scrapy.Field()
    message = scrapy.Field()
    suggestion = scrapy.Field()
    vendorPatch = scrapy.Field()
    chinese = scrapy.Field()
    total = scrapy.Field()
    current = scrapy.Field()

class CnvdItem(scrapy.Item):
    #text = scrapy.Field()
    url = scrapy.Field()
    title = scrapy.Field()
    cveID = scrapy.Field()
    publishTime = scrapy.Field()
    updateTime = scrapy.Field()
    effectSys = scrapy.Field()
    message = scrapy.Field()
    suggestion = scrapy.Field()
    vendorPatch = scrapy.Field()
    chinese = scrapy.Field()
    total = scrapy.Field()
    current = scrapy.Field()
    level = scrapy.Field()


class NvdItem(scrapy.Item):
    #text = scrapy.Field()

    url = scrapy.Field()
    title = scrapy.Field()
    cveID = scrapy.Field()
    type = scrapy.Field()
    publishTime = scrapy.Field()
    updateTime = scrapy.Field()
    effectSys = scrapy.Field()
    message = scrapy.Field()
    suggestion = scrapy.Field()
    vendorPatch = scrapy.Field()
    chinese = scrapy.Field()
    total = scrapy.Field()
    current = scrapy.Field()

class SecurityFocusItem(scrapy.Item):
    #text = scrapy.Field()

    url = scrapy.Field()
    title = scrapy.Field()
    cveID = scrapy.Field()
    type = scrapy.Field()
    publishTime = scrapy.Field()
    updateTime = scrapy.Field()
    effectSys = scrapy.Field()
    message = scrapy.Field()
    suggestion = scrapy.Field()
    vendorPatch = scrapy.Field()
    chinese = scrapy.Field()
    total = scrapy.Field()
    current = scrapy.Field()

class ExploitItem(scrapy.Item):
    #text = scrapy.Field()

    url = scrapy.Field()
    title = scrapy.Field()
    cveID = scrapy.Field()
    type = scrapy.Field()
    publishTime = scrapy.Field()
    EDB_ID = scrapy.Field()
    effectSys = scrapy.Field()
    message = scrapy.Field()
    chinese = scrapy.Field()
    total = scrapy.Field()
    current = scrapy.Field()
    poc = scrapy.Field()

class SeeBugItem(scrapy.Item):
    #text = scrapy.Field()

    url = scrapy.Field()
    title = scrapy.Field()
    cveID = scrapy.Field()
    type = scrapy.Field()
    publishTime = scrapy.Field()
    updateTime = scrapy.Field()
    effectSys = scrapy.Field()
    message = scrapy.Field()
    suggestion = scrapy.Field()
    vendorPatch = scrapy.Field()
    source = scrapy.Field()
    chinese = scrapy.Field()
    total = scrapy.Field()
    current = scrapy.Field()

class SecurityTrackerItem(scrapy.Item):
    #text = scrapy.Field()
    url = scrapy.Field()
    title = scrapy.Field()
    cveID = scrapy.Field()
    publishTime = scrapy.Field()
    updateTime = scrapy.Field()
    effectSys = scrapy.Field()
    type = scrapy.Field()
    message = scrapy.Field()
    suggestion = scrapy.Field()
    vendorPatch = scrapy.Field()
    trackerId = scrapy.Field()
    chinese = scrapy.Field()
    total = scrapy.Field()
    current = scrapy.Field()

class PacketStormSecurityItem(scrapy.Item):

    url = scrapy.Field()
    title = scrapy.Field()
    cveID = scrapy.Field()
    publishTime = scrapy.Field()
    #updateTime = scrapy.Field()
    effectSys = scrapy.Field()
    #type = scrapy.Field()
    message = scrapy.Field()
    detail = scrapy.Field()
    chinese = scrapy.Field()
    total = scrapy.Field()
    current = scrapy.Field()


class MitreItem(scrapy.Item):
    #text = scrapy.Field()
    url = scrapy.Field()
    title = scrapy.Field()
    cveID = scrapy.Field()
    publishTime = scrapy.Field()
    updateTime = scrapy.Field()
    message = scrapy.Field()
    vendorPatch = scrapy.Field()
    chinese = scrapy.Field()
    total = scrapy.Field()
    current = scrapy.Field()



class CnnvdItem(scrapy.Item):
    #text = scrapy.Field()

    url = scrapy.Field()
    title = scrapy.Field()
    cveID = scrapy.Field()
    type = scrapy.Field()
    publishTime = scrapy.Field()
    updateTime = scrapy.Field()
    effectSys = scrapy.Field()
    message = scrapy.Field()
    suggestion = scrapy.Field()
    vendorPatch = scrapy.Field()
    source = scrapy.Field()
    chinese = scrapy.Field()
    total = scrapy.Field()
    current = scrapy.Field()
    level = scrapy.Field()

class MicroItem(scrapy.Item):
    #text = scrapy.Field()

    url = scrapy.Field()
    title = scrapy.Field()
    cveID = scrapy.Field()
    publishTime = scrapy.Field()
    updateTime = scrapy.Field()
    effectSys = scrapy.Field()
    message = scrapy.Field()
    msID =scrapy.Field()
    chinese = scrapy.Field()
    total = scrapy.Field()
    current = scrapy.Field()

class DetailsItem(scrapy.Item):
    #text = scrapy.Field()

    url = scrapy.Field()
    title = scrapy.Field()
    cveID = scrapy.Field()
    type = scrapy.Field()
    publishTime = scrapy.Field()
    updateTime = scrapy.Field()
    message = scrapy.Field()
    level = scrapy.Field()
    chinese = scrapy.Field()
    total = scrapy.Field()
    current = scrapy.Field()

# class SecuniaItem(scrapy.Item):
#     #text = scrapy.Field()
#
#     url = scrapy.Field()
#     title = scrapy.Field()
#     cveID = scrapy.Field()
#     type = scrapy.Field()
#     publishTime = scrapy.Field()
#     updateTime = scrapy.Field()
#     message = scrapy.Field()
#     suggestion = scrapy.Field()
#     level = scrapy.Field()
#     chinese = scrapy.Field()
#     total = scrapy.Field()
#     current = scrapy.Field()
#     effectSys = scrapy.Field()


