import time
from selenium import webdriver
from selenium.webdriver.chrome.options import Options as chromeOptions
from selenium.webdriver.firefox.options import Options as firefoxOptions
class MySelenium():
  agentChrome = 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.139 Safari/537.36'
  agentFireFox = 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv:59.0) Gecko/20100101 Firefox/59.0'
  agentFireFox64 = 'Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:59.0) Gecko/20100101 Firefox/59.0'

  chrome_options = chromeOptions()
  chrome_options.add_argument('--headless')
  chrome_options.add_argument('--user-agent=%s' % agentChrome)

  firefox_options = firefoxOptions()
  firefox_options.add_argument('--headless')
  firefox_options.add_argument('--user-agent=%s' % agentFireFox64)

  def getCookieAndSource(self,url,driverType):
        if(driverType == "chrome"):
            browser = webdriver.Chrome(chrome_options=self.chrome_options)
        else:
            browser = webdriver.Firefox(firefox_options=self.firefox_options)
        browser.implicitly_wait(15)
        browser.get(url)
        time.sleep(2.5)
        cookies = browser.get_cookies()
        source = browser.page_source
        cookie = ''
        cookieDic = {}
        for r in cookies:
            cookie += (r['name'] + "=" + r["value"] + ";")
            cookieDic[r['name']] = r["value"]
        browser.close()
        return [cookie,cookieDic,source]
