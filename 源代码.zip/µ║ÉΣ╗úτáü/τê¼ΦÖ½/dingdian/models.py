# -*- coding: utf-8 -*-
from sqlalchemy import Column, String, create_engine, Integer, Date, Boolean, ForeignKey
from sqlalchemy.dialects.mysql import MEDIUMTEXT,TEXT
from sqlalchemy.orm import sessionmaker,relationship
from sqlalchemy.ext.declarative import declarative_base
import os

# 创建对象的基类:
Base = declarative_base()
Base2 = declarative_base()
# 定义User对象:
class VulNsfocus(Base):
    # 表的名字:
    __tablename__ = 'vul_nsfocus'

    # 表的结构:
    id = Column(Integer, primary_key=True,autoincrement=True)
    url = Column(String(40),unique=True)
    title = Column(String(80))
    cve_id = Column(String(20),index=True)
    publish_time = Column(String(20),index=True)
    update_time = Column(String(20))
    effect_sys = Column(TEXT)
    message = Column(TEXT)
    suggestion = Column(TEXT)
    vendor_patch = Column(TEXT)

class VulNvd(Base):
    # 表的名字:
    __tablename__ = 'vul_nvd'

    # 表的结构:
    id = Column(Integer, primary_key=True,autoincrement=True)
    url = Column(String(80),unique=True)
    title = Column(String(80))
    cve_id = Column(String(20),index=True)
    type = Column(String(127))
    publish_time = Column(String(20),index=True)
    update_time = Column(String(20))
    effect_sys = Column(TEXT)
    message = Column(TEXT)
    suggestion = Column(TEXT)
    vendor_patch = Column(TEXT)

class VulSecurityFocus(Base):
    # 表的名字:
    __tablename__ = 'vul_securityfocus'

    # 表的结构:
    id = Column(Integer, primary_key=True,autoincrement=True)
    url = Column(String(80),unique=True)
    title = Column(String(160))
    cve_id = Column(String(20),index=True)
    type = Column(String(127))
    publish_time = Column(String(20),index=True)
    update_time = Column(String(20))
    effect_sys = Column(MEDIUMTEXT)
    message = Column(TEXT)
    suggestion = Column(TEXT)
    vendor_patch = Column(TEXT)

class VulCnvd(Base):
    # 表的名字:
    __tablename__ = 'vul_cnvd'

    # 表的结构:
    id = Column(Integer, primary_key=True,autoincrement=True)
    url = Column(String(80),unique=True)
    title = Column(String(255))
    cve_id = Column(String(20),index=True)
    publish_time = Column(String(20),index=True)
    update_time = Column(String(20))
    effect_sys = Column(TEXT)
    message = Column(MEDIUMTEXT)
    suggestion = Column(TEXT)
    vendor_patch = Column(TEXT)

class VulSeeBug(Base):
    # 表的名字:
    __tablename__ = 'vul_seebug'

    # 表的结构:
    id = Column(Integer, primary_key=True,autoincrement=True)
    url = Column(String(80),unique=True)
    title = Column(String(255))
    source = Column(String(255))
    cve_id = Column(String(20),index=True)
    publish_time = Column(String(20),index=True)
    update_time = Column(String(20))
    effect_sys = Column(TEXT)
    message = Column(MEDIUMTEXT)
    suggestion = Column(TEXT)
    vendor_patch = Column(TEXT)

class VulExploit(Base):
    # 表的名字:
    __tablename__ = 'vul_exploit'

    # 表的结构:
    id = Column(Integer, primary_key=True,autoincrement=True)
    url = Column(String(80),unique=True)
    title = Column(String(255))
    cve_id = Column(String(20),index=True)
    edb_id = Column(String(8))
    type = Column(String(32))
    publish_time = Column(String(20),index=True)
    update_time = Column(String(20))
    effect_sys = Column(TEXT)
    message = Column(MEDIUMTEXT)
    suggestion = Column(String(2))
    vendor_patch = Column(String(2))

class VulSecurityTracker(Base):
    # 表的名字:
    __tablename__ = 'vul_securitytracker'

    # 表的结构:
    id = Column(Integer, primary_key=True,autoincrement=True)
    url = Column(String(80),unique=True)
    title = Column(String(512))

    cve_id = Column(String(20),index=True)
    tracker_id = Column(String(8))
    type = Column(String(128))
    publish_time = Column(String(20),index=True)
    update_time = Column(String(20))
    effect_sys = Column(TEXT)
    message = Column(MEDIUMTEXT)
    suggestion = Column(String(2))
    vendor_patch = Column(String(255))

class VulPacketStormSecurity(Base):
    # 表的名字:
    __tablename__ = 'vul_packetstormsecurity'

    # 表的结构:
    id = Column(Integer, primary_key=True,autoincrement=True)
    url = Column(String(255),unique=True)
    title = Column(String(512))

    cve_id = Column(String(20),index=True)
    publish_time = Column(String(20),index=True)
    update_time = Column(String(20))
    effect_sys = Column(String(32))
    message = Column(TEXT)
    detail = Column(MEDIUMTEXT)
    suggestion = Column(String(2))
    vendor_patch = Column(String(2))

class VulMitre(Base):
    # 表的名字:
    __tablename__ = 'vul_mitre'

    # 表的结构:
    id = Column(Integer, primary_key=True,autoincrement=True)
    url = Column(String(80))
    title = Column(String(20))
    cve_id = Column(String(20),unique=True)
    publish_time = Column(String(20),index=True)
    update_time = Column(String(20))
    message = Column(TEXT)
    vendor_patch = Column(TEXT)


class VulCnnvd(Base):
    # 表的名字:
    __tablename__ = 'vul_cnnvd'

    # 表的结构:
    id = Column(Integer, primary_key=True,autoincrement=True)
    url = Column(String(160),unique=True)
    title = Column(String(800))
    cve_id = Column(String(20),index=True)
    type = Column(String(127))
    publish_time = Column(String(20),index=True)
    update_time = Column(String(20))
    message = Column(TEXT)
    vendor_patch = Column(TEXT)

class VulMicro(Base):
    # 表的名字:
    __tablename__ = 'vul_micro'

    # 表的结构:
    id = Column(Integer, primary_key=True,autoincrement=True)
    url = Column(String(127),unique=True)
    title = Column(String(255))
    cve_id = Column(String(20),index=True)
    publish_time = Column(String(20),index=True)
    update_time = Column(String(20))
    message = Column(TEXT)
    effect_sys = Column(String(255))
    ms_id = Column(String(16))

class VulDetails(Base):
    # 表的名字:
    __tablename__ = 'vul_details'

    # 表的结构:
    id = Column(Integer, primary_key=True, autoincrement=True)
    url = Column(String(160), unique=True)
    title = Column(String(800))
    cve_id = Column(String(20), index=True)
    type = Column(String(127))
    publish_time = Column(String(20), index=True)
    update_time = Column(String(20))
    message = Column(TEXT)
    #vendor_patch = Column(TEXT)

class VulType(Base2):
    # 表的名字:
    __tablename__ = 'vultype'

    # 表的结构:
    id = Column(Integer, primary_key=True,autoincrement=True)
    type = Column(String(255),unique=True)
    #url = Column(String(127), unique=True)
    vuls = relationship('ShowVuls',backref='types')

class VulLevel(Base2):
    # 表的名字:
    __tablename__ = 'vullevel'

    # 表的结构:
    id = Column(Integer, primary_key=True,autoincrement=True)
    level = Column(String(255),unique=True)
    vuls = relationship('ShowVuls',backref='levels')


class ShowVuls(Base2):
    # 表的名字:
    __tablename__ = 'show_vuls'

    # 表的结构:
    id = Column(Integer, primary_key=True,autoincrement=True)
    url = Column(String(4096))
    title = Column(String(1024))
    cve_id = Column(String(20),index=True,unique=True)
    publish_time = Column(String(20),index=True)
    update_time = Column(String(20))
    message = Column(MEDIUMTEXT)
    poc = Column(String(4096))
    effect_sys = Column(MEDIUMTEXT)
    vendor_patch = Column(TEXT)
    typeid = Column(Integer,ForeignKey('vultype.id'), index=True, nullable=False)
    levelid = Column(Integer, ForeignKey('vullevel.id'), index=True, nullable=False)
    chinese =Column(Boolean)

class Schedule(Base):
    __tablename__ = 'schedule'

    id = Column(Integer, primary_key=True,autoincrement=True)
    spider_name =Column(String(20))
    total = Column(Integer,default=0)
    current = Column(Integer,default=0)
    pid = Column(Integer)
    jobid = Column(String(255),default='')


# if __name__ == "__main__":
#     engine = create_engine('mysql+mysqlconnector://root:950314@localhost:3306/vul')
#
#     Base.metadata.create_all(engine)
