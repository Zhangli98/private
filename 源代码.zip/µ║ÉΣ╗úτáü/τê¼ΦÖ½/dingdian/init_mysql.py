# -*- coding: utf-8 -*-
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from models import Base,Base2
import pymysql
import config

from items import DingdianItem

host = config.get_host()
port = config.get_port()
engine = create_engine('mysql+pymysql://root:123456@'+host+':'+port+'/mydemo?charset=utf8')
#engine = create_engine('mysql+pymysql://root:123456@127.0.0.1:3306/mydemo?charset=utf8')

Base.metadata.create_all(engine)
DBSession = sessionmaker(bind=engine)
session = DBSession()

engine2 = create_engine('mysql+pymysql://root:123456@'+host+':'+port+'/mydemo?charset=utf8')
#engine2 = create_engine('mysql+pymysql://root:123456@127.0.0.1:3306/mydemo?charset=utf8')
Base2.metadata.create_all(engine2)
DBSession2 = sessionmaker(bind=engine2)
session2 = DBSession2()
