#coding:utf-8
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
import os
from models import Base,Vul
import pymysql
import config

host = config.get_host()
port = config.get_port()
engine = create_engine('mysql+pymysql://root:123456@'+host+':'+port+'/vul')
#engine = create_engine('mysql+pymysql://root:123456@127.0.0.1:3306/vul')
Base.metadata.create_all(engine)
DBSession = sessionmaker(bind=engine)
session = DBSession()
vuls = os.listdir('vul_htmls')
#vuls.sort()
#添加
for i in range(1,len(vuls)+1):
    print i
    file_name = vuls[i-1]
    file_path = './vul_htmls/' + file_name
    with open(file_path, "r") as f:
        new_vul = Vul(id='%d'%i, path=file_path,url='http://www.nsfocus.net/vulndb/'+file_name[:-5],text=pymysql.escape_string(f.read()))
        session.add(new_vul)


session.commit()
session.close()

#x.decode('string_escape')
