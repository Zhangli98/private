class global_var:
  hostIP = '172.31.102.33'
  port = '3306'

def get_host():
  return global_var.hostIP

def get_port():
  return global_var.port
