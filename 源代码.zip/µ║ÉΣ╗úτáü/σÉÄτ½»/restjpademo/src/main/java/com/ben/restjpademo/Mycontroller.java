/*package com.ben.restjpademo;

import java.util.ArrayList;

import javax.annotation.Resource;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.ben.restjpademo.dao.CollegeRepository;
import com.ben.restjpademo.domain.College;




@Controller
@RequestMapping("findbyname")
public class Mycontroller {
	@Resource
	CollegeRepository collegeRepository;
	
	
	@ResponseBody
	public ArrayList<College> findbyname(@RequestBody College college){
		String name=college.getCollegename();
		
	}

}
*/