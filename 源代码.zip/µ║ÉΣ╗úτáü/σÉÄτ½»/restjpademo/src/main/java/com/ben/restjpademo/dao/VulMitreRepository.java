package com.ben.restjpademo.dao;

import com.ben.restjpademo.domain.VulMitre;
import org.springframework.data.repository.CrudRepository;


public interface VulMitreRepository extends CrudRepository<VulMitre, Integer> {

    public long count();

}
