package com.ben.restjpademo.dao;

import com.ben.restjpademo.domain.Crawler;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CrawlerRepository extends JpaRepository<Crawler,Integer> {
    Crawler findBySpiderName(String spiderName);
}
