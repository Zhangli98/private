package com.ben.restjpademo.domain;

import com.fasterxml.jackson.annotation.JsonIgnore;

import javax.persistence.*;
import java.util.Collection;

@Entity
public class Vullevel {
    private Collection<ShowVuls> ShowVuls;
    private Integer id;
    private String level;

    @JsonIgnore
    @OneToMany(cascade = CascadeType.ALL,fetch = FetchType.LAZY,mappedBy = "vullevel")
    public Collection<ShowVuls> getShowVuls() {
        return ShowVuls;
    }

    public void setShowVuls(Collection<ShowVuls> ShowVuls) {
        this.ShowVuls = ShowVuls;
    }

    @Id
    @Column(name = "id", nullable = false)
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    @Basic
    @Column(name = "level", nullable = true, length = 255)
    public String getLevel() {
        return level;
    }

    public void setLevel(String level) {
        this.level = level;
    }


}
