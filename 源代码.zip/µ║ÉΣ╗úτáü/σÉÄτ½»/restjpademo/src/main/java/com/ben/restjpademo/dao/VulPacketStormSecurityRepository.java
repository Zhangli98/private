package com.ben.restjpademo.dao;

import com.ben.restjpademo.domain.VulPacketStormSecurity;
import org.springframework.data.repository.CrudRepository;


public interface VulPacketStormSecurityRepository extends CrudRepository<VulPacketStormSecurity, Integer> {

     public long count();

}
