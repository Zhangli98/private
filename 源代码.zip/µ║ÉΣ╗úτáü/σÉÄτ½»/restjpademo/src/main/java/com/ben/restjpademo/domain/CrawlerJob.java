package com.ben.restjpademo.domain;


import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;

@Entity
@Table(name="crawlerJob")
public class CrawlerJob implements java.io.Serializable {

    // Fields
    private Integer id;
    private String status;
    private String jobId;
    private String startTime;
    private String endTime;
    private String spiderName;
    private String total;
    private String current;



    public CrawlerJob() {
    }


    @GenericGenerator(name = "generator", strategy = "increment")
    @Id
    @GeneratedValue(generator = "generator")
    @Column(name = "id", unique = true, nullable = false)
    public Integer getId() {return id; }
    public void setId(Integer id) {this.id = id; }


    @Column(name = "status", nullable = true)
    public String getStatus() {  return status; }
    public void setStatus(String status) { this.status = status; }

    @Column(name = "jobId", nullable = true,unique = true)
    public String getJobId() {  return jobId; }
    public void setJobId(String jobId) { this.jobId = jobId; }

    @Column(name = "startTime", nullable = true)
    public String getStartTime() { return startTime; }
    public void setStartTime(String startTime) { this.startTime = startTime; }

    @Column(name = "endTime", nullable = true)
    public String getEndTime() { return endTime; }
    public void setEndTime(String endTime) { this.endTime = endTime; }

    @Column(name = "spiderName", nullable = true)
    public String getSpiderName() { return spiderName; }
    public void setSpiderName(String spiderName) { this.spiderName = spiderName; }

    @Column(name = "total", nullable = true)
    public String getTotal() {return total;}
    public void setTotal(String total) {this.total = total;}

    @Column(name = "current", nullable = true)
    public String getCurrent() {return current;}
    public void setCurrent(String current) {this.current = current;}

}
