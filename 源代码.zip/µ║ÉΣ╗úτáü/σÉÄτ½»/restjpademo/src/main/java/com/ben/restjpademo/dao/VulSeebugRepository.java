package com.ben.restjpademo.dao;

import com.ben.restjpademo.domain.VulSeebug;
import org.springframework.data.repository.CrudRepository;


public interface VulSeebugRepository extends  CrudRepository<VulSeebug, Integer> {

    public long count();

}
