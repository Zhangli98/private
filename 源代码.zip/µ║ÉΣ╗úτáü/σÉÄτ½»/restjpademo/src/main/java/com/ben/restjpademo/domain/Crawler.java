package com.ben.restjpademo.domain;


import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;

@Entity
@Table(name="crawler")
public class Crawler implements java.io.Serializable {

    // Fields

    private Integer id;
    private String spiderName;


    //    private String status;
//    private String jobId;
//    private String startTime;
//    private String endTime;

    public Crawler() {
    }


    @GenericGenerator(name = "generator", strategy = "increment")
    @Id
    @GeneratedValue(generator = "generator")
    @Column(name = "id", unique = true, nullable = false)
    public Integer getId() {return id; }
    public void setId(Integer id) {this.id = id; }

    @Column(name = "spiderName", unique = true,nullable = true)
    public String getSpiderName() { return spiderName; }
    public void setSpiderName(String spiderName) {  this.spiderName = spiderName; }



}
