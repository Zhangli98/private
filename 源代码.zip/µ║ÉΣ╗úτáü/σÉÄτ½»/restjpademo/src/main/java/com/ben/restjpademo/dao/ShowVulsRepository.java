package com.ben.restjpademo.dao;

import com.ben.restjpademo.domain.ShowVuls;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.data.repository.query.Param;

import java.sql.Date;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;


public interface ShowVulsRepository extends PagingAndSortingRepository<ShowVuls,Integer> {



    public abstract Page<ShowVuls> findAll(Pageable pageable);


    @Query("select c from ShowVuls as c where c.id =:id")
    public abstract ArrayList<ShowVuls> getvuldetailbyvulid(@Param("id") int id);

    @Query("select c from ShowVuls c where c.vultype.id=:typeid")
    public abstract ArrayList<ShowVuls> getvulbytypeid(@Param("typeid") Integer typeid);

    public abstract List<ShowVuls> findByVultype_Type(String type);

    public abstract ShowVuls findById(Integer id);

    @Query("select c from ShowVuls c where c.updateTime between :starttime and :nowtime")
    public abstract List<ShowVuls> findLatestVuls(@Param("starttime") String starttime,@Param("nowtime") String nowtime);


    @Query("select c from ShowVuls  c where c.url like %:url% and c.title like %:title% and c.cveId like %:cveid% and c.publishTime like %:publishtime% and c.updateTime like %:updatetime% and c.effectSys like %:effectsys% and c.message like %:message% and c.poc like %:poc% and c.vendorPatch like %:vendorpatch% and c.typeid =:typeid and c.levelid =:levelid")
    public abstract List<ShowVuls> findAfterSearch(@Param("url") String url, @Param("title") String title, @Param("cveid") String cveid, @Param("publishtime") String publishtime, @Param("updatetime") String updatetime, @Param("effectsys") String effectsys, @Param("message") String message, @Param("poc") String poc, @Param("vendorpatch") String vendorpatch, @Param("typeid") Integer
            typeid,@Param("levelid") Integer levelid);
}