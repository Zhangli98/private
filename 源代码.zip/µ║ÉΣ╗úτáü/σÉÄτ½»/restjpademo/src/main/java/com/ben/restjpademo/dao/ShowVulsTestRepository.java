package com.ben.restjpademo.dao;

import com.ben.restjpademo.domain.ShowVuls;
import org.springframework.data.domain.Page;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

import java.util.Map;


public interface ShowVulsTestRepository extends JpaRepository<ShowVuls,Integer>,JpaSpecificationExecutor<ShowVuls> {



}