package com.ben.restjpademo.dao;

import com.ben.restjpademo.domain.User;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface UserRepository extends PagingAndSortingRepository<User,Integer> {
    @Query("select c from User as c where c.name like %:name% and c.gender like %:gender% and c.phone like %:phone% and c.email like %:email% ")
    public abstract List<User> findAll(@Param("name") String name, @Param("gender") String gender, @Param("phone") String phone, @Param("email") String email);
}
