package com.ben.restjpademo.domain;

import cn.afterturn.easypoi.excel.annotation.Excel;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;

@Entity
@Table(name = "vul_cnnvd", schema = "mydemo", catalog = "")
public class VulCnnvd {
    private int id;
    private String url;
    private String title;
    private String cveId;
    private String type;
    private String publishTime;
    private String updateTime;
    private String message;
    private String vendorPatch;

    @GenericGenerator(name = "generator", strategy = "increment")
    @Id
    @GeneratedValue(generator = "generator")
    @Column(name = "id", unique = true, nullable = false)
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    @Basic
    @Column(name = "url", nullable = true, length = 4096)
    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    @Basic
    @Column(name = "title", nullable = true, length = 1024)
    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    @Basic
    @Column(name = "cve_id", nullable = false, unique = true,length = 20)
    public String getCveId() {
        return cveId;
    }

    public void setCveId(String cveId) {
        this.cveId = cveId;
    }

    @Basic
    @Column(name = "type", nullable = true,length = 127)
    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    @Basic
    @Column(name = "publish_time", nullable = true,length = 20)
    public String getPublishTime() {
        return publishTime;
    }

    public void setPublishTime(String publishTime) {
        this.publishTime = publishTime;
    }

    @Basic
    @Column(name = "update_time", nullable = true,length = 20)
    public String getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(String updateTime) {
        this.updateTime = updateTime;
    }

    @Basic
    @Column(name = "message", nullable = true, columnDefinition="TEXT")
    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }


    @Basic
    @Column(name = "vendor_patch", nullable = true, columnDefinition="TEXT")
    public String getVendorPatch() {
        return vendorPatch;
    }

    public void setVendorPatch(String vendorPatch) {
        this.vendorPatch = vendorPatch;
    }
}
