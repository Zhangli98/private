package com.ben.restjpademo.domain;

import com.fasterxml.jackson.annotation.JsonIgnore;

import javax.persistence.*;
import java.util.Collection;
import java.util.Objects;

@Entity
public class Vultype {
    private Collection<ShowVuls> ShowVuls;
    private Integer id;
    private String type;

    @JsonIgnore
    @OneToMany(cascade = CascadeType.ALL,fetch = FetchType.LAZY,mappedBy = "vultype")
    public Collection<ShowVuls> getShowVuls() {
        return ShowVuls;
    }

    public void setShowVuls(Collection<ShowVuls> ShowVuls) {
        this.ShowVuls = ShowVuls;
    }

    @Id
    @Column(name = "id", nullable = false)
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    @Basic
    @Column(name = "type", nullable = true, length = 100)
    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }


}
