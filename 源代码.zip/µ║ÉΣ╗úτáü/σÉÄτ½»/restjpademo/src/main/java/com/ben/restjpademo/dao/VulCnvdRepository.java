package com.ben.restjpademo.dao;

import com.ben.restjpademo.domain.VulCnvd;
import org.springframework.data.repository.CrudRepository;

public interface VulCnvdRepository extends CrudRepository<VulCnvd, Integer> {

    public long count();

}
