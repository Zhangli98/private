package com.ben.restjpademo.service;

import com.ben.restjpademo.dao.*;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartHttpServletRequest;
import javax.annotation.Resource;

@Controller
@RequestMapping("api")
public class RowController {
    @Resource
    VulCnnvdRepository    vulCnnvdRepository;
    @Resource
    VulCnvdRepository     vulCnvdRepository;
   @Resource
     VulDetailsRepository  vulDetailsRepository;
   @Resource
    VulExploitRepository  vulExploitRepository;
   @Resource
    VulMicroRepository    vulMicroRepository;
   @Resource
    VulMitreRepository    vulMitreRepository;
   @Resource
    VulNsfocusRepository  vulNsfocusRepository;
   @Resource
    VulNvdRepository      vulNvdRepository;
   @Resource
    VulPacketStormSecurityRepository vulPacketStormSecurityRepository;
   @Resource
    VulSecurityFocusRepository vulSecurityFocusRepository;
   @Resource
    VulSecurityTrackerRepository     vulSecurityTrackerRepository;
   @Resource
    VulSeebugRepository   vulSeebugRepository;

    @ResponseBody
    @RequestMapping(value="rows/{table}", method=RequestMethod.GET)
    public long getRows(@PathVariable("table") String tablename) {
           if(tablename.equals("nsfocus"))
            return vulNsfocusRepository.count();
        else if (tablename.equals("cnnvd"))
            return vulCnnvdRepository.count();
        else if (tablename.equals("cnvd"))
            return vulCnvdRepository.count();
        else if (tablename.equals("details"))
            return vulDetailsRepository.count();
        else if (tablename.equals("exploit"))
            return vulExploitRepository.count();
        else if (tablename.equals("micro"))
            return vulMicroRepository.count();
        else if (tablename.equals("mitre"))
            return vulMitreRepository.count();
        else if (tablename.equals("nvd"))
            return vulNvdRepository.count();
        else if (tablename.equals("packetStormSecurity"))
            return vulPacketStormSecurityRepository.count();
        else if (tablename.equals("securityTracker"))
            return vulSecurityTrackerRepository.count();
        else if (tablename.equals("securityFocus"))
            return vulSecurityFocusRepository.count();
        else if (tablename.equals("seebug"))
            return vulSeebugRepository.count();
        else
            return 0;
       
    }

}

