package com.ben.restjpademo.dao;

import com.ben.restjpademo.domain.VulMicro;
import org.springframework.data.repository.CrudRepository;


public interface VulMicroRepository extends CrudRepository<VulMicro, Integer> {

    public long count();

}
