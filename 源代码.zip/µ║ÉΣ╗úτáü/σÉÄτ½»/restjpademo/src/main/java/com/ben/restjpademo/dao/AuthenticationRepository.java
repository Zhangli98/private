package com.ben.restjpademo.dao;

import com.ben.restjpademo.domain.Authentication;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.data.repository.query.Param;

public interface AuthenticationRepository extends PagingAndSortingRepository<Authentication,Integer> {
    @Query("select c from Authentication as c where c.usnm=:username and c.passwd=:passwd")
    public Authentication valiedNameAndPawd(@Param("username") String usernmae, @Param("passwd") String passwd);
    @Query("select c from Authentication as c where c.userByUserid.id=:id")
    public Authentication findByUserId(@Param("id") int userid);
    @Query("select c from Authentication as c where c.usnm=:name")
    public Authentication isNameUnique(@Param("name") String name);
}
