package com.ben.restjpademo.dao;

import com.ben.restjpademo.domain.Schedule;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.data.repository.query.Param;

import java.util.ArrayList;
import java.util.List;


public interface ScheduleRepository extends PagingAndSortingRepository<Schedule,Integer> {



    public abstract List<Schedule> findAll();


}