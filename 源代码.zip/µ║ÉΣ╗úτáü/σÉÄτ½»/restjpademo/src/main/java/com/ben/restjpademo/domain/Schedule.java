package com.ben.restjpademo.domain;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import java.util.Objects;

@Entity
public class Schedule {
    private int id;
    private String spiderName;
    private Integer total;
    private Integer current;
    private Integer pid;
    private String jobid;

    @Id
    @Column(name = "id", nullable = false)
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    @Basic
    @Column(name = "spider_name", nullable = true, length = 20)
    public String getSpiderName() {
        return spiderName;
    }

    public void setSpiderName(String spiderName) {
        this.spiderName = spiderName;
    }

    @Basic
    @Column(name = "total", nullable = true)
    public Integer getTotal() {
        return total;
    }

    public void setTotal(Integer total) {
        this.total = total;
    }

    @Basic
    @Column(name = "current", nullable = true)
    public Integer getCurrent() {
        return current;
    }

    public void setCurrent(Integer current) {
        this.current = current;
    }

    @Basic
    @Column(name = "pid", nullable = true)
    public Integer getPid() {
        return pid;
    }

    public void setPid(Integer pid) {
        this.pid = pid;
    }

    @Basic
    @Column(name = "jobid", nullable = true, length = 255)
    public String getJobid() {
        return jobid;
    }

    public void setJobid(String jobid) {
        this.jobid = jobid;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Schedule schedule = (Schedule) o;
        return id == schedule.id &&
                Objects.equals(spiderName, schedule.spiderName) &&
                Objects.equals(total, schedule.total) &&
                Objects.equals(current, schedule.current) &&
                Objects.equals(pid, schedule.pid) &&
                Objects.equals(jobid, schedule.jobid);
    }

    @Override
    public int hashCode() {

        return Objects.hash(id, spiderName, total, current, pid, jobid);
    }
}
