package com.ben.restjpademo.service;

import com.ben.restjpademo.dao.VullevelRepository;
import com.ben.restjpademo.domain.Vullevel;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;

@Controller
@RequestMapping("api/vullevel")
public class VullevelController {

    @Resource
    VullevelRepository vullevelRepository;


    @ResponseBody
    @RequestMapping(value="/getvullevels",method=RequestMethod.GET)
    public List<Vullevel> findall(){
        List<Vullevel> vullevelList= (List<Vullevel>)vullevelRepository.findAll();
        return vullevelList;
    }


    @ResponseBody
    @RequestMapping(value = "/getvullevel",method = RequestMethod.GET)
    public Vullevel getVullevelByid(@RequestParam(value="id")  Integer id){
        //System.out.println(id);
        Vullevel vullevel = vullevelRepository.findById(id);
        return vullevel;
    }

    @ResponseBody
    @RequestMapping(value="/getvullevel/level={level}",method = RequestMethod.GET)
    public Page<Vullevel> findList(@PathVariable("level") String vullevel ,@PathVariable("page") int page,@PathVariable("size") int size,@PathVariable("sort") String sorts) {
        Sort sort=new Sort(Sort.Direction.DESC,sorts);
        Pageable pageable=new PageRequest(page,size,sort);
        Page<Vullevel> vullevelList= vullevelRepository.findAll(vullevel, pageable);
        for ( Vullevel vullevel1 : vullevelList) {
            System.out.println(vullevel1.getLevel());
        }

        return vullevelList;
    }




}
