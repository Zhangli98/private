package com.ben.restjpademo.dao;

import com.ben.restjpademo.domain.VulDetails;
import org.springframework.data.repository.CrudRepository;


public interface VulDetailsRepository extends CrudRepository<VulDetails, Integer> {

   public long count();

}
