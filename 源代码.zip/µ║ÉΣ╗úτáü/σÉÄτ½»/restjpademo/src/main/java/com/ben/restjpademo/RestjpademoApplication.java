package com.ben.restjpademo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.filter.CharacterEncodingFilter;

@RestController
@SpringBootApplication
public class RestjpademoApplication {

	@RequestMapping("/")
	String return_a_string() {
		return "Spring Data JPA Rest Demo.";
	}
	
    

	public static void main(String[] args) {
		SpringApplication.run(RestjpademoApplication.class, args);
	}
	
	
	@Bean public CharacterEncodingFilter FiltercharacterEncodingFilter() {
		  CharacterEncodingFilter characterEncodingFilter =new CharacterEncodingFilter();
		  characterEncodingFilter.setEncoding("UTF-8");
		  characterEncodingFilter.setForceEncoding(true);
		  return characterEncodingFilter;
		}
}

