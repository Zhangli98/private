package com.ben.restjpademo.domain;

import cn.afterturn.easypoi.excel.annotation.Excel;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;

@Entity
@Table(name = "show_vuls", schema = "mydemo", catalog = "")
public class ShowVuls {
    private int id;

    @Excel(name = "来源",width = 25)
    private String url;

    @Excel(name = "漏洞名称",width = 25)
    private String title;

    @Excel(name = "CVE-ID",width = 25,isImportField = "true_st")
    private String cveId;

    @Excel(name = "发布时间",width = 25)
    private String publishTime;

    @Excel(name = "更新时间",width = 25)
    private String updateTime;

    @Excel(name = "描述",width = 25)
    private String message;

    @Excel(name ="影响系统",width = 25)
    private String effectSys;

    @Excel(name = "补丁",width = 25)
    private String vendorPatch;

    @Excel(name = "poc",width = 25)
    private String poc;

    private Byte chinese;
    private Integer typeid;
    private Vultype vultype;

    private Integer levelid;
    private Vullevel vullevel;


    @GenericGenerator(name = "generator", strategy = "increment")
    @Id
    @GeneratedValue(generator = "generator")
    @Column(name = "id", unique = true, nullable = false)
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    @Basic
    @Column(name = "url", nullable = true, length = 4096)
    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    @Basic
    @Column(name = "title", nullable = true, length = 1024)
    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    @Basic
    @Column(name = "cve_id", nullable = false, unique = true,length = 20)
    public String getCveId() {
        return cveId;
    }

    public void setCveId(String cveId) {
        this.cveId = cveId;
    }

    @Basic
    @Column(name = "publish_time", nullable = true,length = 20)
    public String getPublishTime() {
        return publishTime;
    }

    public void setPublishTime(String publishTime) {
        this.publishTime = publishTime;
    }

    @Basic
    @Column(name = "update_time", nullable = true,length = 20)
    public String getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(String updateTime) {
        this.updateTime = updateTime;
    }

    @Basic
    @Column(name = "message", nullable = true, columnDefinition="TEXT")
    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    @Basic
    @Column(name = "effect_sys", nullable = true, columnDefinition="TEXT")
    public String getEffectSys() {
        return effectSys;
    }

    public void setEffectSys(String effectSys) {
        this.effectSys = effectSys;
    }

    @Basic
    @Column(name = "vendor_patch", nullable = true, columnDefinition="TEXT")
    public String getVendorPatch() {
        return vendorPatch;
    }

    public void setVendorPatch(String vendorPatch) {
        this.vendorPatch = vendorPatch;
    }

    @Basic
    @Column(name = "levelid", nullable = false)
    public Integer getLevelid() {
        return levelid;
    }
    public void setLevelid(Integer levelid) {
        this.levelid = levelid;
    }

    @Basic
    @Column(name = "typeid", nullable = false)
    public Integer getTypeid() {
        return typeid;
    }
    public void setTypeid(Integer typeid) {
        this.typeid = typeid;
    }

    @Basic
    @Column(name = "chinese", nullable = true)
    public Byte getChinese() {
        return chinese;
    }

    public void setChinese(Byte chinese) {
        this.chinese = chinese;
    }

    @Basic
    @Column(name = "poc", nullable = true, length = 4096)
    public String getPoc() {
        return poc;
    }

    public void setPoc(String poc) {
        this.poc = poc;
    }

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "typeid", referencedColumnName = "id", nullable = false,insertable = false,updatable = false)
    public Vultype getVultype() {
        return vultype;
    }

    public void setVultype(Vultype vultype) {
        this.vultype = vultype;
    }


    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "levelid", referencedColumnName = "id", nullable = false,insertable = false,updatable = false)
    public Vullevel getVullevel() {
        return vullevel;
    }

    public void setVullevel(Vullevel vullevel) {
        this.vullevel = vullevel;
    }
}
