package com.ben.restjpademo.dao;

import com.ben.restjpademo.domain.VulSecurityTracker;
import org.springframework.data.repository.CrudRepository;


public interface VulSecurityTrackerRepository extends CrudRepository<VulSecurityTracker, Integer> {

   public long count();

}
