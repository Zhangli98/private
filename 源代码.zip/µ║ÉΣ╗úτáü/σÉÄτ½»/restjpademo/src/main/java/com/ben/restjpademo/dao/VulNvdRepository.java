package com.ben.restjpademo.dao;

import com.ben.restjpademo.domain.VulNvd;
import org.springframework.data.repository.CrudRepository;

public interface VulNvdRepository extends  CrudRepository<VulNvd, Integer> {

    public long count();

}
