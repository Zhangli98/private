package com.ben.restjpademo.dao;

import com.ben.restjpademo.domain.Vullevel;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;

import javax.transaction.Transactional;
import java.util.ArrayList;


@Transactional
@RepositoryRestResource(collectionResourceRel = "",path = "")
public interface VullevelRepository extends PagingAndSortingRepository<Vullevel,Integer> {
    @Query("select c from Vullevel as c where c.level like %:vullevel%")
    public abstract Page<Vullevel> findAll(@Param("vullevel") String level, Pageable pageable);

    @Query("select c from Vullevel as c where c.id like %:id%")
    public abstract ArrayList<Vullevel> getVullevelByid(@Param("id") int id);

    public abstract Vullevel findById(Integer id);





}
