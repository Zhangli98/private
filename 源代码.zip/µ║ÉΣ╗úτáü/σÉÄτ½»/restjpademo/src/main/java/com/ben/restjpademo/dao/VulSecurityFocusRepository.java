package com.ben.restjpademo.dao;

import com.ben.restjpademo.domain.VulSecurityFocus;
import org.springframework.data.repository.CrudRepository;


public interface VulSecurityFocusRepository extends CrudRepository<VulSecurityFocus, Integer> {

     public long count();

}
