package com.ben.restjpademo.domain;

import javax.persistence.*;
import java.util.Objects;

@Entity
public class Authentication {
    private Integer id;
    private String usnm;
    private String passwd;
    private Integer thrscondition;
    private User userByUserid;

    @Id
    @Column(name = "id", nullable = false)
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    @Basic
    @Column(name = "usnm", nullable = true, length = 50)
    public String getUsnm() {
        return usnm;
    }

    public void setUsnm(String usnm) {
        this.usnm = usnm;
    }

    @Basic
    @Column(name = "passwd", nullable = true, length = 50)
    public String getPasswd() {
        return passwd;
    }

    public void setPasswd(String passwd) {
        this.passwd = passwd;
    }

    @Basic
    @Column(name = "thrscondition", nullable = true)
    public Integer getThrscondition() {
        return thrscondition;
    }

    public void setThrscondition(Integer thrscondition) {
        this.thrscondition = thrscondition;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Authentication that = (Authentication) o;
        return Objects.equals(id, that.id) &&
                Objects.equals(usnm, that.usnm) &&
                Objects.equals(passwd, that.passwd) &&
                Objects.equals(thrscondition, that.thrscondition);
    }

    @Override
    public int hashCode() {

        return Objects.hash(id, usnm, passwd, thrscondition);
    }

    @ManyToOne
    @JoinColumn(name = "userid", referencedColumnName = "id")
    public User getUserByUserid() {
        return userByUserid;
    }

    public void setUserByUserid(User userByUserid) {
        this.userByUserid = userByUserid;
    }
}
