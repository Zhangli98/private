package com.ben.restjpademo.dao;

import com.ben.restjpademo.domain.VulCnnvd;
import org.springframework.data.repository.CrudRepository;


public interface VulCnnvdRepository extends CrudRepository<VulCnnvd, Integer> {

    public long count();

}
