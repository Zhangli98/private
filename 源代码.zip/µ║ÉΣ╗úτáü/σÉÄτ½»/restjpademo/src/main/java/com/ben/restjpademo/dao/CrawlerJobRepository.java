package com.ben.restjpademo.dao;

import com.ben.restjpademo.domain.CrawlerJob;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CrawlerJobRepository extends JpaRepository<CrawlerJob,Integer> {
    CrawlerJob findByJobId(String jobId);
    CrawlerJob findBySpiderName(String name);
}
