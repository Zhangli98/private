package com.ben.restjpademo.service;

import com.ben.restjpademo.dao.VultypeRepository;
import com.ben.restjpademo.domain.Vultype;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;

@Controller
@RequestMapping("api/vultype")
public class VultypeController {

    @Resource
    VultypeRepository vultypeRepository;


    @ResponseBody
    @RequestMapping(value="/getvultypes",method=RequestMethod.GET)
    public List<Vultype> findall(){
        List<Vultype> vultypeList= (List<Vultype>)vultypeRepository.findAll();
        return vultypeList;
    }


    @ResponseBody
    @RequestMapping(value = "/getvultype/id={id}",method = RequestMethod.GET)
    public Vultype getVultypeByid(@PathVariable("id") int id){
        Vultype vultype = vultypeRepository.findById(id);
        return vultype;
    }

    @ResponseBody
    @RequestMapping(value="/getvultype/type={type}",method = RequestMethod.GET)
    public Page<Vultype> findList(@PathVariable("type") String vultype ,@PathVariable("page") int page,@PathVariable("size") int size,@PathVariable("sort") String sorts) {
        Sort sort=new Sort(Sort.Direction.DESC,sorts);
        Pageable pageable=new PageRequest(page,size,sort);
        Page<Vultype> vultypeList= vultypeRepository.findAll(vultype, pageable);
        for ( Vultype vultype1 : vultypeList) {
            System.out.println(vultype1.getType());
        }

        return vultypeList;
    }




}
