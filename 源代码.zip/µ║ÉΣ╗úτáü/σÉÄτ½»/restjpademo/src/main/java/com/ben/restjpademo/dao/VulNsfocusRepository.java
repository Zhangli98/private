package com.ben.restjpademo.dao;

import com.ben.restjpademo.domain.VulNsfocus;
import org.springframework.data.repository.CrudRepository;



public interface VulNsfocusRepository extends CrudRepository<VulNsfocus, Integer> {
 
    public long count();

}
