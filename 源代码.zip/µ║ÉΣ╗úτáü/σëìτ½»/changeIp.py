import sys
import os
def alter(file,old_str,ip):
    """
     替换文件中的字符串
     :param file:文件名
     :param old_str:就字符串
     :param new_str:新字符串
     :return:
     """
    file_data = ""
    with open(file, "r", encoding="utf-8") as f:
         for line in f:
             if old_str in line:
                 line = ip
             file_data += line
    with open(file,"w",encoding="utf-8") as f:
         f.write(file_data)

if __name__=="__main__":
   
    ip = sys.argv[1]
    try:
        port = sys.argv[2] 
    except Exception:
        port = "9505"
    path = os.path.abspath(os.path.dirname(__file__))
    path =  os.path.join(path,'src/app/pages')

    common_path = os.path.join(path,'common/serverurl.ts')
    alter(common_path, "export const ServerUrl", "export const ServerUrl='http://"+ip+":"+port+"/';"+os.linesep)

    crawler_path = os.path.join(path,'crawler/crawler.service.ts')
    alter(crawler_path, "@BaseUrl", '''@BaseUrl("http://'''+ip+''':'''+port+'''/api/")'''+os.linesep)  

    crawler_path = os.path.join(path,'vul/services/vul-service.ts')
    alter(crawler_path, "@BaseUrl", '''@BaseUrl("http://'''+ip+''':'''+port+'''/api/")'''+os.linesep)  
    
    crawler_path = os.path.join(path,'vul/components/vul-list/vul-list.component.ts')
    alter(crawler_path, "baseUrl = ", '''baseUrl = "http://'''+ip+''':'''+port+'''/api/showvuls/";'''+os.linesep)  
    
