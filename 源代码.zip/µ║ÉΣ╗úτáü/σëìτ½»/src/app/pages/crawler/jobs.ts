
export  class  MyJob{
  id:number;
  status:string;
  jobId:string;
  startTime:string;
  endTime:string;
  spiderName:string;
  total:string;
  current:string;
  disabledButton:boolean;
}
