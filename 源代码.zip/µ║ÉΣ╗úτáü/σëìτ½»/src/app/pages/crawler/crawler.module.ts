import { NgModule }      from '@angular/core';
import { CommonModule }  from '@angular/common';
import { FormsModule } from '@angular/forms';
import { NgaModule } from '../../theme/nga.module';

import { Crawler } from "./crawler.component";
import { routing } from "./crawler.routing";

import { MyCrawlerService } from "./crawler.service";
import {NgbProgressbarModule} from "@ng-bootstrap/ng-bootstrap";

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    NgaModule,
    NgbProgressbarModule,
    routing
  ],
  declarations: [
    Crawler,
  ],
  providers: [
    MyCrawlerService
  ],
  entryComponents: [
  ]
})
export class CrawlerModule {}
