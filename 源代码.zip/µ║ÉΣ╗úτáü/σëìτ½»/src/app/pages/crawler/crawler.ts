
export  class  MyCrawler{

  id: number;

  spiderName:string;
  //
  // status:string;
  // jobId:string;
  // startTime:string;
  // endTime:string;



}
