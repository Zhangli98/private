import { Routes, RouterModule }  from '@angular/router';

import { Crawler } from "./crawler.component";

// noinspection TypeScriptValidateTypes
const routes: Routes = [
  {
    path: '',
    component: Crawler,
  }
];

export const routing = RouterModule.forChild(routes);
