import { Injectable } from "@angular/core";
import { Http, Request, Response } from '@angular/http';
import { Observable } from "rxjs/Observable";
import { RESTClient, GET, PUT, POST, DELETE, BaseUrl, Header, DefaultHeaders, Path, Body, Query } from '../common/angular2-rest';
import {AuthHttp} from "angular2-jwt";
import {ServerUrl} from "../common/serverurl";



@Injectable()
@BaseUrl(ServerUrl + 'api/')
//@BaseUrl("http://127.0.0.1:8080/api/")
@DefaultHeaders({
	'Accept':'application/json',
	'Content-Type':'application/json'
	})

export class MyCrawlerService extends RESTClient {

  public constructor(http: Http) {
    super(http);
  }

  protected reqestInterceptor(req: Request) {

  }

  protected responseInterceptor(res: Observable<Response>): Observable<Response> {
    return res;
  }

  @GET("crawlers/")
  public getCrawlers(): Observable<any> {
    return null;
  }

  @POST("crawlers/create")
  public createCrawlers(@Body spiderName:String): Observable<any> {
    return null;
  }

  @POST("crawlers/cancel")
  public cancelCrawlers(@Body jobId:String): Observable<any> {
    return null;
  }

  @GET("jobs/")
  public getJobs(): Observable<any> {
    return null;
  }

  @GET("jobs/{id}")
  public getJobById( @Path("id") id: string): Observable<any> { return null; };


  @DELETE("jobs/delete/{id}")
  public deleteJobByJobId( @Path("id") id: string): Observable<any> { return null; };

  @GET("rows/{table}")
  public getTotal( @Path("table") table: string): Observable<any> { return null; };

  @GET("jobs/percent/{spider}/{id}")
  public getPercent( @Path("id") id: string, @Path("spider") spider: string): Observable<any> { return null; };

  @GET("jobs/endtime/{spider}/{id}")
  public getEndtime( @Path("id") id: string, @Path("spider") spider: string): Observable<any> { return null; };
}
