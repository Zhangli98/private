import {Component, Input, OnInit} from '@angular/core';
import {NgbActiveModal, NgbModal} from '@ng-bootstrap/ng-bootstrap';
import {Vul} from "../../../domain/vul";
import {Response} from "@angular/http";
import {VulsService} from "../../../services/vul-service";

@Component({
  selector: 'dfmodal',
  styleUrls: [('./default-modal.component.scss')],
  templateUrl: './default-modal.component.html'
})

export class VulModal implements OnInit {

  modalHeader1: string = "漏洞详情";

  disabled:boolean;
  disabled1:boolean;

  selectedvul=new Vul();

  constructor(private vulservice :VulsService,private modalService:NgbModal,private activeModal: NgbActiveModal) {
  }

  ngOnInit() {}

  closeModal() {
    this.activeModal.close();
  }

  cancel():void{
    this.activeModal.close();
  }
  edit():void{
    this.disabled=false;
    this.disabled1=false;
  }

  save(): void {
    let myvul = this.selectedvul;
    //let a=this.vuldetail;
    this.vulservice.updataVul(myvul.id, myvul).subscribe((res: Response) => {


        alert('状态码:' + res.status + " 更新成功");
        location.reload();

      },
      error => {
        console.log(error);
        alert("更新失败")
      },
      () => {
        console.log("更新完成");
        this.activeModal.close();;
      });
  }



}
