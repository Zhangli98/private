export * from './default-modal.component';
