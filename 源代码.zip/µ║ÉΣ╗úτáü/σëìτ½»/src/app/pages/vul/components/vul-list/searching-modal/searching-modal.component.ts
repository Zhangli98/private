import {Component, Input, OnInit} from '@angular/core';
import {NgbActiveModal, NgbModal} from '@ng-bootstrap/ng-bootstrap';
import {Vul} from "../../../domain/vul";
import {Response} from "@angular/http";
import {VulsService} from "../../../services/vul-service";

@Component({
  selector: 'searchingmodal',
  styleUrls: [('./searching-modal.component.scss')],
  templateUrl: './searching-modal.component.html'
})

export class SearchingModal implements OnInit {

  modalHeader1: string = "查询中";



  constructor(private vulservice :VulsService,private modalService:NgbModal,private activeModal: NgbActiveModal) {
  }

  ngOnInit() {}

  closeModal() {
    this.activeModal.close();
  }




}
