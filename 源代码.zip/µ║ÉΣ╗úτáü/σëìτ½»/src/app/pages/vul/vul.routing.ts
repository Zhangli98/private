import { Routes, RouterModule }  from '@angular/router';
import {Vuls} from "./vul.component";
import {Vullist} from "./components/vul-list";



// noinspection TypeScriptValidateTypes
const routes: Routes = [
  {
    path: '',
    component:Vuls,
    children: [/*{ path: 'proxycontroller/proxylist',component:Proxylist}*/
      { path:'vullist',component:Vullist }
    ]
  }
];

export const routing = RouterModule.forChild(routes);
