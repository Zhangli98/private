/**
 * Created by ashii on 2018/3/18.
 */

import {Injectable, Query} from "@angular/core";
import {BaseUrl, DefaultHeaders, RESTClient, GET, Path, PUT, Body, DELETE, POST} from "../../common/angular2-rest";
import {Http, Request, Response} from "@angular/http";
import {Observable} from "rxjs";
import {Vul} from "../domain/vul";
import {AuthHttp} from "angular2-jwt";
//import {Http} from "angular2-jwt/angular2-jwt";
import {ServerUrl} from "../../common/serverurl";


@Injectable()
@BaseUrl(ServerUrl + 'api/')
@DefaultHeaders({
  'Accept':'application/json',
  'Content-Type':'application/json'
})

export class VulsService extends  RESTClient{

  public constructor(http:Http){
    super(http);
  }

  protected requestInterceptor(req:Request){

  }
  protected responseInterceptor(res:Observable<Response>):Observable<Response>{
    return res;
  }



  @GET('showvuls/getvul?url={url}&title={title}&cveid={cveid}&publishtime={publishtime}&updatetime={updatetime}&effectsys={effectsys}&message={message}&poc={poc}&vendorpatch={vendorpatch}&levelid={levelid}&typeid={typeid}&page={page}&size={size}&sort={sort}')
  public getVuls(@Path('url') url:string ,
                 @Path('title') title:string ,
                 @Path('cveid') cveid:string ,
                 @Path('publishtime') publishtime:any ,
                 @Path('updatetime') updatetime:any ,
                 @Path('effectsys') effectsys:string ,
                 @Path('message') message:string ,
                 @Path('poc') poc:string ,
                 @Path('vendorpatch') vendorpatch:string ,
                 @Path('levelid') levelid:any,
                 @Path('typeid') typeid:any,
                 @Path('page') page:number,
                 @Path('size') size:number,
                 @Path('sort') sort:string):Observable<any>{return null}

  @GET('showvuls/getvul/url={url}&title={title}&cveid={cveid}&publishtime={publishtime}&updatetime={updatetime}&effectsys={effectsys}&message={message}&poc={poc}&vendorpatch={vendorpatch}&typeid={typeid}')
  public getVulsWithNoPage(@Path('url') url:string ,@Path('title') title:string ,@Path('cveid') cveid:string ,@Path('publishtime') publishtime:any ,
                           @Path('updatetime') updatetime:any ,@Path('effectsys') effectsys:string ,@Path('message') message:string ,
                           @Path('poc') poc:string ,@Path('vendorpatch') vendorpatch:string ,@Path('typeid') typeid:number):Observable<any>{return null}

  @GET('vul/getvul/id={id}')
  public getVulsbyId(@Path('id') id:number):Observable<any>{return null}

  @GET('vul/getvuls/page={page}&size={size}&sort={sort}')
  public getVulsbyNoParam(@Path('page') page:number,@Path('size') size:number, @Path('sort') sort:string):Observable<any>{return null}

  @PUT('showvuls/{id}')
  public  updataVul(@Path('id') id:number,@Body vul:Vul):Observable<any>{return null}

  @DELETE('showvuls/{id}')
  public  deleteVul(@Path('id') id:number):Observable<any>{return null}

  @POST('vuls/')
  public  createVul(@Body vul:Vul):Observable<any>{return null}

  @GET('vultype/getvultypes')
  public getVultypesbyNoParam():Observable<any>{return null}

  @GET('vullevel/getvullevels')
  public getVullevelsbyNoParam():Observable<any>{return null}

  @GET('/showvuls/getvuls/page={page}&size={size}&sort={sort}')
  public getAllVuls(@Path('page') page:number,
                    @Path('size') size:number,
                    @Path('sort') sort:string):Observable<any>{
    return null
  }
}
