
import {Component} from "@angular/core";
@Component({
  selector:'vuls',
  template: `<router-outlet></router-outlet>`,
  styles:[]
})


export class Vuls{
  constructor(){

  }
}
