/**
 * Created by ashii on 2018/3/18.
 */
export class Vul
{
  id: number;
  title: string;
  cveId: string;
  publishTime: any;
  updateTime: any;
  effectSys: string;
  message: string;
  poc: string;
  vendorPatch: string;
  typeid: number;
  levelid: number;
  url: string;


}
