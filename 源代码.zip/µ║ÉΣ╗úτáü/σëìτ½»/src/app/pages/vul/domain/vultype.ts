/**
 * Created by ashii on 2018/4/30.
 */

export class Vultype
{
  id:number;
  type:string;

}
