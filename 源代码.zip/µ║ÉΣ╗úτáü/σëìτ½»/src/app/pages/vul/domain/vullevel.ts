/**
 * Created by dy on 2018/7/04.
 */

export class Vullevel
{
  id:number;
  level:string;

}
