import {NgModule} from "@angular/core";
import {Vuls} from "./vul.component";
import {CommonModule} from "@angular/common";
import {FormsModule} from "@angular/forms";
import {NgaModule} from "../../theme/nga.module";
import {routing} from "./vul.routing";
import {ModalModule, PaginationModule} from "ng2-bootstrap";
import {VulsService} from "./services/vul-service";
import {CalendarModule} from "primeng/components/calendar/calendar";
import {Vullist} from "./components/vul-list";
import {FileUploadModule} from "ng2-file-upload";

@NgModule({
  declarations:[
    Vuls,
    Vullist,


  ],
  imports:[
    PaginationModule,

    CommonModule,
    FormsModule,
    NgaModule,
    routing,
    ModalModule,
    CalendarModule,
    FileUploadModule
  ],
  providers:[
    VulsService,
  ],




})

export class VulsModule{}
