export class Self {
	constructor (public href: string = null) {}
}

