import { Self } from './self';

export class Links {
	constructor (public self:Self= null) {}
}
