/**
 * Created by ÁõÄþ on 2017/4/29.
 */

import {Component, ViewEncapsulation} from "@angular/core";
@Component({
  selector:'logout',
  encapsulation:ViewEncapsulation.None,
  styleUrls:['logout.scss'],
  templateUrl: './logout.html',
})

export class LogoutComponent{

}
