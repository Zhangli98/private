/**
 * Created by ÁõÄþ on 2017/4/29.
 */

import {Injectable} from "@angular/core";
import {Http} from "@angular/http";
import {AuthHttp, tokenNotExpired, JwtHelper} from "angular2-jwt";
import {Response, Request} from "@angular/http";
import {Observable} from "rxjs";
import {BaseUrl, DefaultHeaders, RESTClient, GET, Path} from "../common/angular2-rest";
import {ServerUrl} from "../common/serverurl";
@Injectable()
@BaseUrl(ServerUrl+'api/')
@DefaultHeaders({
  'Accept': 'application/json',
  'Content-Type': 'application/json'
})

export class LogoutService extends RESTClient{

  constructor(http: Http){
    super(http);
  }
  protected reqestInterceptor(req: Request){

  }
  protected responseInterceptor(res:Observable<Response>):Observable<Response>{
    return res;
  }

  @GET('logout/id={id}')
  public logout(@Path('id') id:number): Observable <any> {return null}
}
