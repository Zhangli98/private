import {Routes, RouterModule} from "@angular/router";
import {LogoutComponent} from "./logout.component";
/**
 * Created by ÁõÄþ on 2017/4/29.
 */

const routes:Routes=[
  {
    path: '',
    component: LogoutComponent
  }
]

export const routing = RouterModule.forChild(routes);
