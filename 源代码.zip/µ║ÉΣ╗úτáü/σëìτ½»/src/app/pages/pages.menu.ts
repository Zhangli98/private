export const PAGES_MENU = [

  {
    path: 'pages',
    children: [


      {
        path: 'crawler',
        data: {
          menu: {
            title: '爬虫列表',
            icon: 'ion-wand',
            selected: false,
            expanded: false,
            order: 50
          }
        },
      },




      {
        path: 'vuls',
        data: {
          menu: {
            title: '漏洞模块',
            icon: 'ion-cube',
            selected: false,
            expanded: false,
            order: 50,

          }
        },
        children: [
          {
            path: 'vullist',
            data: {
              menu: {
                title: '漏洞列表',
                icon: 'ion-android-list',
              }
            }
          },
        ]
      },



    ]
  }
];
