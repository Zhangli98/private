import { Routes, RouterModule }  from '@angular/router';
import { Pages } from './pages.component';
import { ModuleWithProviders } from '@angular/core';
// noinspection TypeScriptValidateTypes

// export function loadChildren(path) { return System.import(path); };

export const routes: Routes = [
  {
    path: 'login',
    loadChildren: './login/login.module#LoginModule'
  },
  {
    path: 'pages',
    component: Pages,
    children: [
      { path: '', redirectTo: 'dashboard', pathMatch: 'full' },
      { path: 'crawler', loadChildren: './crawler/crawler.module#CrawlerModule' },
      { path: 'vuls', loadChildren: './vul/vul.module#VulsModule' } ,


    ]
  },
  {
    path: 'logout',
    loadChildren: './logout/logout.module#LogoutModule'
  }
];

export const routing: ModuleWithProviders = RouterModule.forChild(routes);
