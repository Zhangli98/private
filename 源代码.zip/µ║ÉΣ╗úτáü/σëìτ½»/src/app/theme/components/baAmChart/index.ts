export * from './baAmChart.component';
