import {Component, OnInit, ChangeDetectionStrategy, ChangeDetectorRef} from '@angular/core';

import {BaMsgCenterService} from './baMsgCenter.service';
import {JwtHelper} from "angular2-jwt";
import {Router} from "@angular/router";
import {LogoutService} from "../../../pages/logout/logout.service";

@Component({
  selector: 'ba-msg-center',
  providers: [BaMsgCenterService],
  styleUrls: ['./baMsgCenter.scss'],
  templateUrl: './baMsgCenter.html',
})
export class BaMsgCenter implements OnInit{

  public notifications:Array<Object>
  public messages:Array<Object>;
  //liuning 20170427
  public jwtHelper: JwtHelper = new JwtHelper();
  public username:string;
  public role:string;
  public time:string;
  public date:Date;
  public day:string;
  public week:string[]= ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday']//
  constructor(private _baMsgCenterService:BaMsgCenterService,private ref: ChangeDetectorRef,private router:Router
    ,private logoutservice:LogoutService) {
    this.notifications = this._baMsgCenterService.getNotifications();
    this.messages = this._baMsgCenterService.getMessages();
    setInterval(() => {
      var data = new Date();
      this.date=data;
      var houer = data.getHours()<10?"0"+data.getHours():data.getHours();
      var minute = data.getMinutes()<10?"0"+data.getMinutes():data.getMinutes();
      var second = data.getSeconds()<10?"0"+data.getSeconds():data.getSeconds();
      this.time = houer + ":" + minute + ":" + second;
      //this.day = this.week[this.date.getDay()];
      this.ref.markForCheck();
    }, 1000);
  }

  ngOnInit(){
    let token = localStorage.getItem('token');
    this.username = this.jwtHelper.decodeToken(token).sub;
  }
  public singout(){
    let id=this.jwtHelper.decodeToken(localStorage.getItem('token'))['userid'];
    this.logoutservice.logout(id).subscribe(data=>{
      localStorage.removeItem('token');
      this.router.navigate(['/logout']);
    },error=>{console.log(error);alert("登出失败")},()=>{})
  }
}

// import {Component} from '@angular/core';
//
// import {BaMsgCenterService} from './baMsgCenter.service';
//
// @Component({
//   selector: 'ba-msg-center',
//   providers: [BaMsgCenterService],
//   styleUrls: ['./baMsgCenter.scss'],
//   templateUrl: './baMsgCenter.html'
// })
// export class BaMsgCenter {
//
//   public notifications:Array<Object>;
//   public messages:Array<Object>;
//
//   constructor(private _baMsgCenterService:BaMsgCenterService) {
//     this.notifications = this._baMsgCenterService.getNotifications();
//     this.messages = this._baMsgCenterService.getMessages();
//   }
//
// }
