HOME=`pwd`
service mysql start
service nginx start
cd $HOME && nohup npm start &
cd $HOME/dingdian && nohup scrapyd & 
cd $HOME/restjpademo && nohup mvn spring-boot:run &


