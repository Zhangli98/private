# 依赖

## python：

pip2  install bs4 selenium pymysql jsonpath sqlalchemy Scrapy==1.6.0 Twisted==18.9.0 scrapyd scrapyd-client -i https://pypi.tuna.tsinghua.edu.cn/simple

## chrome和chromedriver

## nvm 

node 6.9.4, npm 3.10.10
依赖安装：
在项目目录下 npm install

## 数据库

设置为utf8 

mysql ，创建数据库database mydemo

mysql -uroot -p123456 < authentication.sql

# 启动

## 0.每次启动前准备

删除mydemo数据库，删除dingdian文件夹下

![image-20200910173103967](/Users/liyl/Library/Application Support/typora-user-images/image-20200910173103967.png)

这些多余文件，保留文件夹dingdian，scrap.cfg, scarped-deploy, set-up.py 以及虚拟环境文件夹

## 1.启动scrapyd

进入dingdian文件夹, scrapyd

## 2. 部署漏洞

scrapyd-deploy -p vul

## 3. 启动前端

在web 目录下npm start 启动前端

## 4. 启动后端

在restjpademo目录下，mvn spring-boot:run启动后端

# 代码结构
## 后端

### dao

连接数据库的接口

### 持久层（dao包）

hibernate框架

`ShowVulsRepositor`接口

### domain包

entity（实体）

相关权限的：

1. User类
2. Authentication 

### service包（其实是controller)

动态查询

ShowVulsController 类：

​	Specification

### jwtangspr包

管理权限

使用jwt

### 用户注册

当前使用的方式是，写数据库，在authentication.sql里

## 前端

angular2

开源项目（ng2-admin) 基于angular2

#### 源码位置

web/src/app/pages/vul

#### vul代码结构

##### domain包

定义组件的属性

##### service包

负责和后端通信

用htttp

##### components包

定义函数、html、css等

调用service定义的通信函数请求数据

## 爬虫

scrapy框架

scrapyd 管理爬虫